# Lite 方案常見問題

Q: 可以自己 regenerate 嗎？
A: 可以。PERSONA_OUTPUT=$PWD python3 tools/_generate_997.py

Q: 品質有保證嗎？
A: Lite 不含 QA 驗證工具，再生品質由甲方自行驗證。

Q: 可以賣改進後的資料嗎？
A: 可以。不可轉售 tool 本身。

Q: 怎麼升級到 Transfer？
A: 補差價 NT$45K-65K。或按 session log NT$2,000/hr。

Q: 跟 Transfer 差在哪？
A: Transfer 含 qa_validate.py + 機率表 + scripts + skills 目錄 + 方法論交接。

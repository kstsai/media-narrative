# TW Persona DB — Appliance Lite v3.2

NT$15,000 — 資料 + 查詢 + 生成引擎（不含 QA 驗證）

## 包含
- data/tw_persona_1069.json — 1,069 筆台灣人設
- tools/query_persona.py — 查詢 CLI
- tools/_generate_997.py — 重新生成引擎
- data/qualified-memory.md — 24 條 domain knowledge

## 快速開始
python3 tools/query_persona.py --list-dimensions
python3 tools/query_persona.py --residence 台北市 --age 35-44 --occ 科技 --top 3

## 重新生成
PERSONA_OUTPUT=$PWD python3 tools/_generate_997.py

## 升級
新版本需求另計 NT$2,000/hr，依 session log 計費。

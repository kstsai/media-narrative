# TW Persona DB Appliance — 常見問題 (FAQ)

## Q: 查詢回 0 筆怎麼辦？

**最常見原因**：組合太細，人口權重不足。

解法：
```bash
# 原本（太細，可能回 0）
python3 query_persona.py --residence 新竹市 --age 45-54 --occupation 科技 --family_size 4

# 放寬 region（新竹市人口僅 ~1.9%）
python3 query_persona.py --residence 新竹縣 --age 45-54 --occupation 科技

# 或放寬年齡
python3 query_persona.py --residence 新竹市 --age 35-54 --occupation 科技
```

如果所有條件都放寬還是 0，那就是這個組合在真實人口中真的極少。

---

## Q: 為什麼台北市的 persona 這麼多？離島這麼少？

這是**人口加權抽樣**的結果。1069 筆的分配比例 = 真實台灣人口比例：
- 台北市 ~11% → ~118 筆
- 離島（澎湖/金門/連江）合計 ~1.5% → ~16 筆

不是遺漏，是人口比例如此。

---

## Q: 這份資料跟真實政府統計差多少？

| 項目 | 誤差 |
|:-----|:----:|
| 年齡分布 | ≤ 0.3% |
| 區域分布 | ≤ 0.4% |
| 性別比 | 49.7:50.3（實際 49.5:50.5） |
| 縣市覆蓋 | 22/22 |
| 資料源 | 7 個官方統計（ODRP014、DGBAS、主計總處、內政部） |

---

## Q: 我可以自己加資料或改資料嗎？

可以。`data/tw_persona_1069.json` 是標準 JSON 格式。
- 要新增維度：直接在 JSON 的 dimensions 加欄位
- 要修改 prompt：編輯對應欄位
- 建議保留原始備份

注意：自行修改後，本尊後續的 qualified memory 更新可能與你的修改衝突。

---

## Q: 我可以把資料嵌入我的網站或服務嗎？

可以。`tw_persona_1069.json` 是永久授權，可用於商業產品內部。
- 不可轉售原始資料
- 不可再授權給第三方
- 基於資料分析的衍生結果（報表、圖表）不受限制

---

## Q: 跟傳統外包建人設資料庫差在哪？

| 項目 | 這個 Appliance | 傳統外包 |
|:-----|:--------------|:---------|
| 價格 | NT$XX,000 一次 | NT$80K-150K |
| 筆數 | 1069 | 500-1000 |
| 維度 | 18 | 8-12 |
| 品質驗證 | 20 條 QA 規則 | 通常無系統驗證 |
| 查詢工具 | CLI 即時查詢 | 通常只給 Excel |
| 迭代能力 | 可自行擴充 | 全部重做 |

---

## Q: 什麼情況下該找 Kuo-Shou？

**建議找她：**
- major version upgrade（v3.x → v4.0）
- 需要疊加全新維度（如選舉投票紀錄、消費偏好）
- 發現資料有系統性錯誤
- 需要完全重建（如日本版、越南版）

**不用找她：**
- query 回 0 筆（先放寬條件）
- 想改 prompt 文案（自行編輯 JSON）
- 基本操作問題（先看 README 和 qualified-memory.md）

---

## Q: 更新會不會把我的修改蓋掉？

`auto-import-qualified.sh` 只會覆蓋：
- `data/tw_persona_1069.json`
- `skills/tw-persona-db/`
- `tools/*.py`

不會動到你自己新增或修改的檔案。如果不放心，更新前先備份 `data/` 目錄。

---

## Q: 我可以不用 Hermes Agent，直接用 query_persona.py 嗎？

**可以。** query_persona.py 是獨立 Python 腳本，不需要 Hermes Agent。
只需要 Python 3 標準函式庫（json、csv、argparse、collections）。

這也是為什麼把它包成 CLI 而不是 Hermes skill 的 main 介面——低依賴，高可攜。

---

## Q: prompt_prefix 和 reference_pre_prompt 有什麼差？

- **prompt_prefix**：角色扮演用。餵給 LLM 讓它扮演該 persona 回答問卷。
- **reference_pre_prompt**：結構化摘要。GEO 操作員（你）過濾查詢用。

兩個都是同一 persona 的不同呈現方式。

---

## Q: 為什麼有些背景故事看起來怪怪的？

背景故事是模板引擎生成的（3 組模板池隨機組合），已知可能出現：
- 經濟語氣不一致（bg 說寬鬆、pre 說緊）
- 65+ persona 用「小孩」而不是「子女」
- 喪偶+family>1 仍說「一個人過日子」

這些是本尊持續迭代改善中的項目。如果你看到讓你在意的新 pattern，可以回報給 Kuo-Shou。

---

_最後更新: {datetime.now().strftime('%Y-%m-%d')}_

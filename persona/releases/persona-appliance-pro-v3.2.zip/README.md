# TW Persona DB — Appliance v3.2

> 1069 筆台灣人設資料庫查詢工具
> 產出日期: 2026-07-13

## 這是什麼

一套 1069 筆人口加權台灣人設資料庫 + CLI 查詢工具。
18 維度結構化資料，涵蓋年齡/性別/區域/教育/職業/收入/政治/媒體/家庭/婚姻/興趣等。

## 系統需求

- Python 3.8+
- 無需網路連線（離線可查）
- 建議 4GB+ RAM（載入 1.4MB JSON 無壓力）

## 快速開始

```bash
# 1. 解壓縮
unzip persona-appliance-v3.2.zip -d ~/persona-db/

# 2. 進入目錄
cd ~/persona-db

# 3. 開始查詢
python3 tools/query_persona.py --residence 台北市 --age 35-44 --occupation 科技
python3 tools/query_persona.py --list-dimensions
python3 tools/query_persona.py --residence 台中市 --politics 泛綠 --top 5
```

## 常用查詢範例

| 目標 | 指令 |
|:-----|:-----|
| 查選區分布 | `python3 tools/query_persona.py --residence 台中市 --age 30-44 --politics 泛綠` |
| 查展店客群 | `python3 tools/query_persona.py --residence 高雄市 --income >8萬 --family_size 3+` |
| 查金融商品 | `python3 tools/query_persona.py --age 25-40 --occupation 科技/金融 --marriage 未婚` |
| 列出所有維度 | `python3 tools/query_persona.py --list-dimensions` |
| 模糊搜尋職業 | `python3 tools/query_persona.py --occ ~工程` |
| 只看前 3 筆 | `上列指令加 --top 3` |

## 18 維度速查

| # | 維度 | 合法值 |
|---|------|--------|
| 1 | age | 0-11 / 12-18 / 19-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| 2 | sex | 男 / 女 |
| 3 | region | 都會區(六都) / 北部 / 中部 / 南部 / 花東 / 離島 |
| 4 | education | 國中以下 / 高中 / 大學 / 研究所以上 |
| 5 | occupation | 學生 / 科技 / 服務 / 製造 / 教育 / 醫療 / 公務 / 自營 / 家管 / 退休 / 其他 |
| 6 | personal_income | <3萬 / 3-8萬 / >8萬 / 無收入 |
| 7 | politics | 泛綠 / 泛藍 / 白/第三勢力 / 無政治傾向 |
| 8 | media_diet | 家長主導 / 兒童內容為主 / 傳統媒體為主 / 社群為主 / 混合 / 國際來源 |
| 9 | family_size | 1 / 2 / 3 / 4 / 5+ |
| 10 | family_income | <1萬 / 1-3萬 / 3-7萬 / 7萬 / 百萬 |
| 11 | hobby | 打電動 / 追劇 / 閱讀 / 登山 / 游泳 / 球類 / 逛街購物 / 烹飪 / 園藝 / 泡茶 / 下棋 / 打牌 / 繪畫 / 音樂 / 廣場舞 |
| 12 | marriage | 未婚 / 已婚 / 離婚 / 鰥寡 |
| 13 | residence | 台北市 ~ 連江縣（22 縣市） |
| 14-18 | 政治立場/議題/物價/所得級 | 見 RFC |

## 已知限制

1. **小縣市人少**：新竹市 ~1.9%、離島 ~1.1%、金門 ~0.3%。極端組合（新竹市+45-54+科技+4口）可能回 0。請放寬 region 條件。
2. **職業加成**：新竹縣/市 30%→科技、台北市 20%→金融、桃園市 20%→製造。這是基於實際產業分布。
3. **物價/所得分級**：依據 DGBAS 官方數據，參見 RFC 及 references。
4. **背景故事為模板生成**：可能出現經濟語氣不一致（如「手頭寬鬆」+「收入低」），屬已知 issue，本尊持續改善中。

## 更新方式

當有 major release 時（如 v3.2 → v4.0），會收到通知：

```bash
# 下載新版 ZIP
# 解壓縮覆蓋
unzip -o persona-appliance-v4.0.zip -d ~/persona-db/

# 或使用自動更新腳本
bash tools/auto-import-qualified.sh persona-appliance-v4.0.zip
```

## 聯絡與支援

- **日常操作問題**：先查 FAQ.md 和 qualified-memory.md
- **資料品質問題 / major upgrade 需求**：聯絡 Kuo-Shou（類心理師方案，NT$3,000/hr）
- bug fix（vv3.2 範圍內含 3 個月修正支援）

---

_文件版本: vv3.2 | 產出時間: 2026-07-13 05:00_

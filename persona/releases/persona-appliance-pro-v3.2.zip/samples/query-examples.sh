#!/bin/bash
# query-examples.sh — 常用查詢範例
# 用法: bash query-examples.sh

QUERY="python3 tools/query_persona.py"

echo "╔══════════════════════════════════════════════╗"
echo "║  TW Persona DB — 常用查詢範例               ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

echo "=== 1. 台北市 35-44 歲科技業 ==="
$QUERY --residence 台北市 --age 35-44 --occupation 科技 --top 3

echo ""
echo "=== 2. 台中市 30-44 歲泛綠選民 ==="
$QUERY --residence 台中市 --age 30-44 --politics 泛綠 --top 3

echo ""
echo "=== 3. 高雄市高收入有家庭 ==="
$QUERY --residence 高雄市 --income ">8萬" --family_size "3+" --top 3

echo ""
echo "=== 4. 全台 25-40 未婚科技/金融 ==="
$QUERY --age 25-34 --age 35-44 --marriage 未婚 --occ ~工程 --occ ~金融 --top 5

echo ""
echo "=== 5. 新竹市科技業（測試城市加成） ==="
$QUERY --residence 新竹市 --occupation 科技 --top 5

echo ""
echo "=== 6. 列出所有可用維度 ==="
$QUERY --list-dimensions

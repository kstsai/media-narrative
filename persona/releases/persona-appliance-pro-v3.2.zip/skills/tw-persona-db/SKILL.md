---
name: tw-persona-db
description: "Taiwan Persona Database — 1069 population-weighted personas across 18 base dimensions. Generate, query, analyze, and extend the persona DB for GEO operator use or domain-specific stacking."
version: 3.6.0
author: Hermes Agent
license: MIT
platforms: [linux]
metadata:
  hermes:
    tags: [persona, taiwan, demographic, geo, population-sampling, chinese]
    related_skills: [cross-media-narrative]
  user:
    kstsai:
      persona_defaults:
        language: "Traditional Chinese (台灣正體中文)"
        output_format: "JSON with prompt_prefix + reference_pre_prompt"
---

# TW Persona Database

A database of 1069 population-weighted persona templates representing Taiwan's ~23 million demographic structure, built for **GEO (Generative Engine Optimization) Operator** use.

## Core Architecture

### 18 Dimensions

| # | Dimension | Levels |
|---|-----------|--------|
| 1 | 年齡 Age | 0-11 / 12-18 / 19-24 / 25-34 / 35-44 / 45-54 / 55-64 / 65+ |
| 2 | 性別 Sex | 男 / 女 |
| **3** | **區域 Region** | **都會區(六都) / 北部 / 中部 / 南部 / 花東 / 離島** |
| 4 | 教育 Education | 國中以下 / 高中 / 大學 / 研究所以上 |
| 5 | 職業 Occupation | 學生 / 科技 / 服務 / 製造 / 教育 / 醫療 / 公務 / 自營 / 家管 / 退休 / 其他 |
| 6 | 個人收入 Personal Income | <3萬 / 3-8萬 / >8萬 / 無收入 |
| 7 | 政治傾向 Politics | 泛綠 / 泛藍 / 白/第三勢力 / 無政治傾向 |
| 8 | 媒體習慣 Media Diet | 家長主導 / 兒童內容為主 / 傳統媒體為主 / 社群為主 / 混合 / 國際來源 |
| 9 | 家庭口數 Family Size | 1 / 2 / 3 / 4 / 5+ |
| 10 | 家庭可支配所得 Family Income | <1萬 / 1-3萬 / 3-7萬 / 7萬 / 百萬 |
| 11 | 興趣嗜好 Hobby | 打電動 / 追劇 / 閱讀 / 登山 / 游泳 / 球類 / 逛街購物 / 烹飪 / 園藝 / 泡茶 / 下棋 / 打牌 / 繪畫 / 音樂 / 廣場舞 |
| 12 | 婚姻狀況 Marriage | 未婚 / 已婚 / 離婚 / 鰥寡 |
| **13** | **戶籍地 Residence** | **台北市 ~ 連江縣 (22 縣市)** |
| 14 | 政治立場 Political Stance | Free-text stance per leaning group |
| 15 | 政治議題 Political Issues | 2 issues per persona with political affiliation |
| 16 | 背景故事 Background Story | Generated narrative (household + economics + life stage) |
| **17** | **物價分級 Price Tier** | **高 / 中高 / 中 / 低 / 極低** |
| **18** | **家戶所得分級 HH Income Tier** | **極高 / 高 / 中 / 中低 / 低** |

**Region (dim 3) → Residence (dim 13) mapping:**
- 都會區(六都) → 台北市, 新北市, 桃園市, 台中市, 台南市, 高雄市
- 北部 → 基隆市, 新竹縣, 新竹市, 苗栗縣, 宜蘭縣
- 中部 → 彰化縣, 南投縣, 雲林縣
- 南部 → 嘉義市, 嘉義縣, 屏東縣
- 花東 → 花蓮縣, 台東縣
- 離島 → 澎湖縣, 金門縣, 連江縣

**Residence → Price Tier (dim 17) mapping** — 113年度 DGBAS 平均每人月消費支出:
- **高** (>112% of 26,640): 台北市(34,952), 新竹縣(30,014)
- **中高** (102-112%): 新竹市, 台中市, 新北市, 嘉義市
- **中** (90-102%): 高雄市, 桃園市, 基隆市
- **低** (80-90%): 宜蘭縣, 台南市, 屏東縣, 苗栗縣, 花蓮縣, 嘉義縣
- **極低** (<80%): 金門縣, 雲林縣, 彰化縣, 澎湖縣, 連江縣, 台東縣, 南投縣
See `references/residence-price-index.md`.

**Residence → HH Income Tier (dim 18) mapping** — 2024 DGBAS 每戶可支配所得:
- **極高** (>140% of 1,165,000): 新竹縣(1,868,845), 新竹市(1,858,010), 台北市(1,803,192)
- **高** (115-140%): 桃園市, 新北市, 嘉義市, 台中市
- **中** (95-115%): 高雄市, 基隆市, 台南市, 宜蘭縣
- **中低** (80-95%): 屏東縣, 苗栗縣, 花蓮縣, 嘉義縣, 南投縣, 雲林縣, 彰化縣, 金門縣
- **低** (<80%): 台東縣, 連江縣, 澎湖縣
See `references/household-income-by-city.md`.

**Interaction**: `price_tier` (dim 17) adjusts **economic phrase selection** in background_story — high-cost cities get more 「月底手頭緊」. `hh_income_tier` (dim 18) adjusts **family_income probability** — high-income cities get shifted toward 百萬/7萬.

### Dual Prompt Format

Each persona has two prompt variants:
- **`prompt_prefix`** — Immersive role-play text for LLM consumption (first-person/third-person narrative)
- **`reference_pre_prompt`** — Structured summary for GEO operator filtering

### Naming Convention (10 Pools)

Names match persona age/sex/occupation automatically via 10+ dedicated naming pools (~15-16 names each). Names cycle through the pool via `deque.popleft+append` to ensure diversity even for high-count combos.

| # | Pool | Age | Sex | Style | Size | Examples |
|---|------|:---:|:---:|:-----:|:----:|----------|
| 1 | 0-11 | 0-11 | any | Cute reduplicated | 16 | 糖糖, 樂樂, 星星, 萌萌 |
| 2 | 12-18 | 12-18 | any | Japanese 醬系 | 16 | 小莓, 星醬, 泡泡, 雨醬 |
| 3 | young-m-tech | 19-34 | 男 | Western tech | 16 | 阿睿, 馬克, 文森, 艾力克 |
| 4 | young-m-other | 19-34 | 男 | 阿/小系 | 16 | 小宇, 阿杰, 阿峰, 大雄 |
| 5 | young-f | 19-34 | 女 | Anglophone | 16 | 小艾, 莉亞, 安妮, 菲菲 |
| 6 | mid-m | 35-54 | 男 | Steady 雙字 | 16 | 志豪, 強哥, 正雄, 信賢 |
| 7 | mid-f | 35-54 | 女 | Elegant 雙字 | 16 | 靜怡, 慧君, 淑娟, 怡君 |
| 8 | pre-retire-m | 55-64 | 男 | 本土中年 | 15 | 信宏, 國華, 清輝, 朝陽 |
| 9 | pre-retire-f | 55-64 | 女 | 本土中年 | 15 | 秀英, 玉蘭, 月鳳, 秀琴 |
| 10 | senior-m | 65+ | 男 | 伯系 | 15 | 春伯, 福伯, 松伯, 梅伯 |
| 11 | senior-f | 65+ | 女 | 嬸系 | 15 | 春姨, 金花嬸, 銀嬸, 鳳嬸 |
| — | else | (edge) | — | Mixed | 16 | 秀蘭, 阿坤, 萬福, 阿雪 |

### Three Prompt Templates (Randomized)

Each persona gets one of three prompt_prefix formats, randomly assigned with seed=42:

- **Template A (40%)** — Third-person descriptive
  - Seniors (65+): `這是{name}，{specific_age}歲了，住{residence}。{story}。平常喜歡{hobby}。{stance}{econ_ctx}`
  - Others: `{name}是{age_sex_str}，住在{residence}。{story}。平常喜歡{hobby}。{stance}{econ_ctx}`
- **Template B (35%)** — First-person natural
  - Seniors (65+): `你們可以叫我{name}，{specific_age}歲了，住{residence}。{first_story}放假喜歡{hobby}。{stance}{econ_ctx}`
  - Kids (ad): `我叫{name}，是{ad}，住{residence}。{first_story}放假喜歡{hobby}。{stance}{econ_ctx}`
  - Adults: `我叫{name}，{specific_age}歲，住{residence}，{occ_phrase}。{first_story}放假喜歡{hobby}。{stance}{econ_ctx}`
- **Template C (25%)** — Concise natural
  - Seniors (65+): `我是{name}，{specific_age}歲，住{residence}，{occ_phrase}。{first_story}。興趣是{hobby}。{stance}{econ_ctx}`
  - Others: `我是{name}，{ad if ad else f'{specific_age}歲'}，住在{residence}，{occ_phrase}。{first_story}。興趣是{hobby}。{stance}{econ_ctx}`

**Key improvement — Senior speech naturalness (added v3.3)**:
Before: `我叫碧嬸，是阿姨，住花蓮縣。` (robotic, no real elder talks like this)
After: `你們可以叫我碧嬸，72歲了，住花蓮縣。` (natural: "you can call me…, I'm 72…")

All three templates have separate branches for `age == "65+"` that:
- Use `specific_age()` instead of `ad` (阿伯/阿姨) in the intro
- Frame the opening naturally: 「這是{name}」/「你們可以叫我{name}」/「我是{name}」
- Apply to all elderly personas consistently

**Key improvements:**
- `age_desc()`: 0-11→國小男生/女生, 12-18→國/高中男生/女生, **65+→阿伯/阿姨**
- `specific_age()`: Converts age brackets (e.g., "45-54") to a specific integer (e.g., 47) for natural phrasing. 65+ returns random 65-78; 0-11 returns 3-11. The reference_pre_prompt keeps the bracket for GEO filtering.
- `occ_phrase()`: 退休→「已經退休了」, 學生→「還在讀書」, 家管→「在家照顧家庭」, 公務→「當公務員」, 自營→「自己做生意」
- `strip_trailing_location()`: Removes redundant "住在XX" from background_story when used in prompt_prefix
- **Location in prefix**: Uses `residence` (city/county name like "台北市") instead of `region` (macro-label like "都會區(六都)"), making prompts sound natural.
- **Economic context sentence** (`gen_econ_context()`) appended after stance: compares personal_income vs local price_tier and generates a sentence like "在台北市這個收入不太夠用，物價太高了。" or "在台東縣收入算很高了，日子過得滿舒服的。" Same income, different city → different sentence. Minors skipped; no-income personas (students/retirees/homemakers) use family_income as proxy. See `references/economic-context-sentences.md` for the full logic table.

## Files & Paths

All under `/home/ubuntu/lab-riscv/hermesa3/persona/`:

| File | Description |
|------|-------------|
| `tw_persona_1069.json` | Final output — 1069 personas, ~1.4MB |
| `_generate_997.py` | Generation script (seed=42, TARGET=1069) |
| `qa_validate.py` | 18-rule automated coherence checker |
| `sample_stratified.py` | Stratified sampling: 96 entries (6 regions × 8 ages × 2 sexes) |
| `query_persona.py` | CLI query tool with dimension filters |
| `population_by_region_age_sex_2025.csv` | 6 regions × 8 ages × 2 sexes population data |
| `occ_prob_real.py` | Real OCC_PROB from DGBAS 2024 Table 47 (replacement for estimated values in _generate_997.py) |
| `marriage_prob_real.py` | Real MARRIAGE_PROB from MOI 2024 data (population + divorce counts + divorce rates) — replaces estimated values |
| `tw-persona-db-rfc.md` | RFC specification document |
| `MILESTONE-v3.0.md` | Changelog from v1.5→v3.0 |
| `references/96-sample-v3-review-2026-07-11.md` | Comprehensive 96-sample review (v3.0) |
| `references/chunk6-contradiction-patterns.md` | Economic tone contradictions in chunk 6 (174 personas) — confirms chunk 3 patterns |
| `references/chunk4-contradiction-patterns.md` | Chunk 4 (179 personas 55-64+65+) — 10-category contradiction analysis, template contamination bug, 子女/孫輩 confusion |
| `references/economic-context-sentences.md` | Income × price_tier logic table for gen_econ_context() |
| `references/residence-price-index.md` | DGBAS consumption data per city (price tiers) |
| `references/household-income-by-city.md` | DGBAS household income data per city (income tiers) |
| `references/chunk3-contradiction-patterns.md` | Economic tone contradictions found in chunk 3 |
| `references/chunk4-contradiction-patterns.md` | Chunk 4 analysis: template contamination, 子女/孫輩 confusion |
| `references/chunk6-contradiction-patterns.md` | Confirms chunk 3 economic tone patterns at higher frequency |
| `references/session-2026-07-11-chunked-review.md` | Methodology for 6-chunk full-dataset contradiction analysis |
| `references/dgbas-manpower-survey-2024.md` | DGBAS 113年人力資源調查統計年報 表47 — occupation×age×sex data for OCC_PROB |
| `tw_persona_prototype_001_v3.json` | Prototype: 叩莓 (high school student) |
| `tw_persona_prototype_002_engineer.json` | Prototype: 阿睿 (engineer) |
| `tw_persona_top10.json` | First 10 sample personas |

**Population source**: `population_by_region_age_sex_2025.csv` — 23.4M real-proportion data (household registration stats), organized as 6 regions × 8 ages × 2 sexes × population count. Used for REGION_POP in `_generate_997.py`.

## Workflows

### A. Regenerate Personas

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 _generate_997.py
```

Output: overwrites `tw_persona_1069.json`. TARGET=1069 hardcoded.

**OCC_PROB now uses real DGBAS data**: The `OCC_PROB` dict in `_generate_997.py` was updated (2026-07-12) from estimated values to real data extracted from DGBAS 2024 Table 47 (113年人力資源調查統計年報). The reference file `occ_prob_real.py` contains the raw extraction output.

Key differences from old estimates:
| Category | Old Estimate | Real Data |
|:---------|:------------:|:---------:|
| 25-54男 製造 | 15-25% | **39-49%** (largest employer) |
| 25-34男 科技 | 30% | **16%** |
| 自營 (all ages) | 10-20% | **1-3%** |
| 金融 | ~5-10% | **0** (not a DGBAS category) |
| 65+女 退休 | 85% | **28%** (majority are 家管 67%) |

See `references/dgbas-manpower-survey-2024.md` for the full data source documentation and mapping methodology.

**Occupation Boost by City**: `OCC_CITY_BOOST` in `_generate_997.py` redirects base OCC_PROB selection for key cities:
- 新竹縣/新竹市: 30% → 科技 (竹科 effect)
- 台北市: 20% → 金融 (finance hub)
- 桃園市: 20% → 製造
- 台中/台南/高雄: 15% → 製造
This is applied post-selection, before income is computed. Excludes students, retirees, and 65+.

**Population limitation**: Cities with small populations (新竹市 ~1.9%, 離島 ~1.1%) get very few personas even at 1069 total (~24 and ~16 respectively). Very specific combos (city + age + occupation + family_size) may return 0 results even with occupation boost. The boost helps shift distributions but cannot create personas from zero sampling slots. Query tool shows this clearly; relax criteria or increase sample size.

### G. Full-Dataset Parallel Pro Review (6 chunks)

For comprehensive semantic contradiction detection across all 1069 personas:

1. **Split** the JSON into 6 chunks (~179 each):
   ```bash
   python3 -c "
   import json, math
   with open('tw_persona_1069.json') as f:
       data = json.load(f)
   n = len(data)
   cs = math.ceil(n / 6)
   for i in range(6):
       chunk = data[i*cs:min((i+1)*cs, n)]
       with open(f'tw_persona_chunk_{i+1}.json', 'w') as f:
           json.dump(chunk, f, ensure_ascii=False, indent=2)
   "
   ```

2. **Dispatch** 3+3 Pro agents in parallel:
   ```python
   delegate_task(tasks=[
       {"goal": "analyze chunk 1", "context": "FILE: chunk_1.json"},
       {"goal": "analyze chunk 2", "context": "FILE: chunk_2.json"},
       {"goal": "analyze chunk 3", "context": "FILE: chunk_3.json"},
   ])
   ```
   Then repeat for chunks 4-6.

3. **Each agent** runs a 10-check mechanical script first, then applies semantic judgment to distinguish REAL contradictions from false positives. The script covers:
   - Income vs narrative tone mismatch (bg comfortable → prefix tight, and reverse)
   - Single-living + child expenses (without spouse context)
   - Married + family_size=1 without spouse mention
   - Minor with income
   - 65+ with "獨生子" language
   - 含飴弄孫 + low income + high price tier
   - Minor with non-student occupation
   - Background_story internal contradictions
   - Student + married coexistence
   - 12-18 with education=大學

4. **Consolidate** findings across chunks — most issues repeat across chunks; track by type not count.

5. **Verify** each finding programmatically before fixing. Do NOT trust sub-agent claims at face value.

### B. Run QA

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 qa_validate.py
# Exit 0 = ALL CLEAN, exit N = N violations
```

20 rules: R1-未成年獨居, R2-未成年經濟短語, R3-模糊家庭描述, R4-舊格式prefix, R5-專業低學歷, R6-分布合理性, R7-名字多樣性, R8-學生離婚, R9-兒童媒體習慣, R10-65+歳殘留, R11-做退休/做學生, R12-【】模板格式, R13-獨生子/獨生女, R14-45+新婚不久, R15-地點重複, R16-55+新婚短語, R17-未滿55兒孫滿堂, R18-未成年泡茶, R19-家庭人數矛盾, R20-中高齡未婚家庭描述

### B2. Generate Verification Report (after QA passes)

After QA passes, produce a population-statistics verification report that proves output matches real census data. Run the distribution analysis:

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 -c "
import json
from collections import Counter
with open('tw_persona_1069.json') as f:
    data = json.load(f)
total = len(data)

# Age vs expected
AGE_EXPECTED = {'0-11':0.11,'12-18':0.07,'19-24':0.07,'25-34':0.14,'35-44':0.16,'45-54':0.16,'55-64':0.15,'65+':0.14}
ages = Counter(p['dimensions']['age'] for p in data)
for k in ['0-11','12-18','19-24','25-34','35-44','45-54','55-64','65+']:
    ap = ages[k]/total*100; ep = AGE_EXPECTED[k]*100
    print(f'{k}: {ages[k]} ({ap:.1f}%) 目標{ep:.1f}% 差異{ap-ep:+.1f}%')

# Region vs expected
REGION_EXPECTED = {'都會區(六都)':0.694,'北部':0.103,'中部':0.103,'南部':0.067,'花東':0.023,'離島':0.011}
regions = Counter(p['dimensions']['region'] for p in data)
for k in ['都會區(六都)','北部','中部','南部','花東','離島']:
    ap = regions[k]/total*100; ep = REGION_EXPECTED[k]*100
    print(f'{k}: {regions[k]} ({ap:.1f}%) 目標{ep:.1f}% 差異{ap-ep:+.1f}%')

# Sex
sexes = Counter(p['dimensions']['sex'] for p in data)
print(f'男={sexes[\"男\"]} ({sexes[\"男\"]/total*100:.1f}%) 女={sexes[\"女\"]} ({sexes[\"女\"]/total*100:.1f}%)')
"
```

Key thresholds for a healthy generation:
- Age error ≤ 0.5% per bracket
- Region error ≤ 0.5% per region
- Sex error ≤ 1.0%
- QA exit code = 0 (all 20 rules pass)
- 22/22 cities covered

Expected output for a healthy run (1069 target):
- 1069 total personas
- ~64 coherence fixes (varies slightly per run)
- ~15-17% name uniqueness (168+ unique names)
- Documentation: write to `GENERATION-VERIFICATION-YYYY-MM-DD.md` and commit alongside the JSON if publishing to public repo.

### C. Stratified Sampling Review (Dual-Pass)

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 sample_stratified.py
# → tw_persona_96_stratified.json (96 entries: 6 regions × 8 ages × 2 sexes)
```

**Pass 1 — Automated checks:**
```bash
python3 scripts/persona_review.py
# Checks 5 categories: A(分布異常), B(內容), C(語言), D(物價/所得), E(Region)  
# Validates all 22 county/city price & income tiers
# Validates all 96 region↔residence mappings
```

**Pass 2 — Deep semantic review:**
```bash
python3 scripts/persona_review_deep.py
# Checks: background coherence, economic contradictions, prefix quality
```

**Pass 3 — Sub-agent naturalness review:**
Spawn DeepSeek Pro sub-agent for naturalness & reasonableness review:
```
delegate_task(context=<file path + domain knowledge>,
              goal="Analyze 96 samples for naturalness & reasonableness")
```

**Pitfalls discovered in practice:**
- **Population weighting limits city-level coverage**: Cities with small populations (新竹市 ~1.9%, 離島 ~1.1%) get very few personas (17-19 each). Very specific combos (city + age + occupation + family_size) may return 0 results even with occupation boost. Query tool shows this clearly.
- **OCC_CITY_BOOST helps but cannot create personas from zero sampling slots**: A city with 17 people and a 30% tech boost still may not have a 45-54 tech worker with 4-person family. Increase sample size or relax query criteria.
- background_story often still uses region macros (「住在都會區」) even when prefix uses specific residence. The generator's template_source for background_story needs updating — it's a different code path from prefix generation.
- Economic context sentence in prefix may contradict background_story's economic tone if background_story was generated from old template pools. Always check both sides.
- 「國中/高中」 prefix label vs `education` dimension mismatch: `age_desc()` infers school level from age range, not actual `education` field. Fix by checking `education` field when generating age description.
-「沒有生小孩」+ 後文提到「小孩開銷」is a template pool composition error: the 3 background groups are independently drawn and can contradict each other.
- **「現在一個人過日子」template contamination (chunk 4)**: The widowed-person ending routine unconditionally appends "現在一個人過日子" even when earlier template pools filled in 「兒孫滿堂」「三代同堂」. This creates direct contradictions in 65+ personas. Fix: skip this phrase when `family_size > 1` or when the background already describes cohabitation.
- **65+ 子女/孫輩 language**: 65+ personas should use 「子女」「兒女」for adult children and 「孫子/孫女」for grandchildren, never 「小孩」which implies young children. The 65+ template pools still use youth-oriented family language.

### E. Price & Income Tier Verification

After regeneration, verify that both `price_tier` and `hh_income_tier` affect persona outputs as expected:

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 scripts/verify_economic_tone.py
```

For single-chunk analysis, pass the chunk path directly:

```bash
python3 scripts/verify_economic_tone.py tw_persona_chunk_6.json
```

This script checks 4 patterns: bg comfortable→pre tight, bg tight→pre comfortable, married family_size=1 but bg says cohabitation, and personal vs family income mismatch for single-person households.

**Cross-chunk trend**: Chunk 6 analysis (see `references/chunk6-contradiction-patterns.md`) confirms the same economic tone patterns found in chunk 3 but at higher frequency (23 vs 13 instances of bg-comfortable→pre-tight). The primary root cause remains the `econ_by_tier()` variable scoping trap — it defaults to `inc_level=\"3-8萬\"` when `inc` isn't passed, so low-income personas get comfortable background phrases.

Expected: Taipei should have more tight phrases and higher income distribution than Nantou.

### F. Query Personas

```bash
# Exact match by dimension
python3 query_persona.py --residence 新竹市 --occ 科技 --age 35-44

# List available dimension values
python3 query_persona.py --list-dimensions

# Fuzzy match (prefix with ~)
python3 query_persona.py --occ ~工程

# Top N results
python3 query_persona.py --residence 台北市 --income ">8萬" --top 3
```

Note: Due to population weighting (~1.9% = 19 personas per city), very specific combinations (e.g., 新竹市 + 45-54 + 科技 + 4口) may return 0 results. The tool only filters — it does not relax criteria. For missing combos, try broader filters or check `--list-dimensions` for valid values.

```bash
python3 _generate_997.py 2>&1 | tail -30
```

Or use Python directly for custom queries.

### D. Contradiction Analysis (10-Check)

Run the generic checker against any persona chunk:

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 ../.hermes/skills/research/tw-persona-db/scripts/persona_contradiction_check.py tw_persona_chunk_4.json
```

The script runs 10 mechanical checks and outputs all flagged items:

1. **收入 vs 描述** — low-income (<3萬) with comfortable lang, or high-income (>8萬) with tight lang
2. **獨居+小孩** — family_size=1 mentioning children without spouse context
3. **已婚+fs=1無配偶** — married + alone + no spouse mention in narrative
4. **未成年有收入** — age 0-18 with income > 無收入
5. **65+年輕子女** — 65+ describing young children's expenses
6. **含飴弄孫+低收入+高物價** — 含飴弄孫 + <3萬 + high price tier combo
7. **未成年非學生** — age 0-18 with non-student occupation
8. **BG前後句矛盾** — internal contradictions in background_story
9. **學生+已婚** — student with non-未婚 marriage
10. **12-18教育=大學** — age 12-18 with university education

After mechanical flags, apply **semantic judgment** to classify each as:
- **REAL** — genuine contradiction (e.g., bg says "寬裕" but pp says "要省")
- **OK** — explainable (e.g., "有些積蓄" with low income — savings ≠ income)
- **MINOR** — editorial issues (e.g., "老伴走了" repeated in same sentence)

Known patterns from chunk 4 analysis (see `references/chunk4-contradiction-patterns.md`):
- Template contamination: "現在一個人過日子" appended to 兒孫滿堂 personas
- 65+ 子女/孫輩 language confusion: "小孩開銷" used when "子女開銷" is correct
- Income vs narrative mismatch: bg and pp use different template pools

### E. Price & Income Tier Verification

After regeneration, verify that both `price_tier` and `hh_income_tier` affect persona outputs as expected:

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona
python3 scripts/verify_economic_tone.py
```

For single-chunk analysis, pass the chunk path directly:

```bash
python3 scripts/verify_economic_tone.py tw_persona_chunk_6.json
```

This script checks 4 patterns: bg comfortable→pre tight, bg tight→pre comfortable, married family_size=1 but bg says cohabitation, and personal vs family income mismatch for single-person households.

**Cross-chunk trend**: Chunk 6 analysis (see `references/chunk6-contradiction-patterns.md`) confirms the same economic tone patterns found in chunk 3 but at higher frequency (23 vs 13 instances of bg-comfortable→pre-tight). The primary root cause remains the `econ_by_tier()` variable scoping trap — it defaults to `inc_level=\"3-8萬\"` when `inc` isn't passed, so low-income personas get comfortable background phrases.

Expected: Taipei should have more tight phrases and higher income distribution than Nantou.

<!-- Duplicate removed -->

## Business Operations — Client Delivery via Qualified Memory

This skill supports a **memory continuity** business model: the user (本尊) iterates the persona DB, and clients (甲方) receive periodic releases containing curated (qualified) knowledge + data + tools.

### Core Concept: Qualified Memory

The user's `~/.hermes/memories/MEMORY.md` can contain entries tagged with `#qualified`. These are curated knowledge nuggets deemed safe and useful for clients:

```
🟢 已知限制：查新竹市+科技業+45-54可能回0，因人口權重低（新竹市~1.9%）。 #qualified
🟢 最佳 query：--residence 台中市 --age 30-44 --politics 泛綠 #qualified
```

Only entries with `#qualified` (or `#export`) are packaged into releases. Everything else stays local to the 本尊.

### Export Workflow

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona

# List what's tagged #qualified
python3 export_qualified_memory.py --list-qualified

# Build a release (auto-bumps minor version)
python3 export_qualified_memory.py

# Build with explicit version
python3 export_qualified_memory.py --version v3.4

# Also generate the client-side import script
python3 export_qualified_memory.py --gen-import-script

# Dry run (no files written)
python3 export_qualified_memory.py --dry-run
```

The script lives at `persona/export_qualified_memory.py` and is also mirrored under this skill's `scripts/` directory for portability.

### Appliance Build (分身 — Standalone Deployable)

For clients who don't want a full Hermes instance, build a **standalone persona appliance** — a self-contained ZIP with data + tools + skill, no Hermes dependency:

```bash
cd /home/ubuntu/lab-riscv/hermesa3/persona

# Build appliance (reads version from VERSION file)
python3 build_appliance.py

# Build with explicit version
python3 build_appliance.py --version v3.2

# Build with optional Flask API server
python3 build_appliance.py --with-api

# Dry run
python3 build_appliance.py --dry-run
```

Output: `releases/persona-appliance-v3.2.zip`

#### Appliance vs Release: Which to Use

| Deliverable | Script | Contents | Client needs | Pricing model |
|:------------|:-------|:---------|:-------------|:--------------|
| **Release** | `export_qualified_memory.py` | qualified-memory + skill + data + tools | Has Hermes Agent instance | Monthly subscription (NT$15K-25K/mo) |
| **Appliance** | `build_appliance.py` | README + FAQ + data + tools + skill (no Hermes) | Just Python 3 | One-time sale (NT$60K-80K) + hourly updates |

**Appliance delivery checklist** is documented in `persona/appliance-checklist.md` (internal — not shipped to client).

**Appliance pricing model:**
- One-time sale (NT$60K-80K) — client self-hosts, self-maintains
- Major version upgrades (v3.x → v4.0): revert to 類心理師 hourly (NT$3,000/hr)
- Bug fix support: 3 months included in sale price
- This avoids the "vendor relationship" trap with the ex-boss dynamic — one clean transaction, then occasional upgrade projects

#### Appliance Directory Structure

```
persona-appliance-v3.2.zip
├── VERSION
├── README.md                 ← Quick-start guide for client
├── FAQ.md                    ← Pre-empting likely questions
├── data/
│   ├── tw_persona_1069.json
│   ├── population_by_region_age_sex_2025.csv
│   ├── tw-persona-db-rfc.md
│   └── qualified-memory.md   ← 24 curated entries (from conversation history)
├── tools/
│   ├── query_persona.py
│   ├── sample_stratified.py
│   ├── auto-import-qualified.sh
│   └── (api_server.py — optional Flask wrapper)
├── skills/tw-persona-db/     ← Simplified SKILL.md (internal sections stripped)
│   ├── SKILL.md
│   ├── references/            ← Selected (10 refs — dimension, language, pricing)
│   └── scripts/               ← Selected (review scripts only)
└── samples/query-examples.sh
```

#### What Appliance Excludes (本尊保留)

| File | Reason |
|:-----|:-------|
| `_generate_997.py` | Core iteration engine — your IP |
| `qa_validate.py` | QA is your responsibility, not client's tool |
| `export_qualified_memory.py` | Your release pipeline — client doesn't produce releases |
| `BUSINESS-MODEL.md`, `MILESTONE-*.md` | Internal documents |
| Chunk analysis refs (`chunk3/4/6-*.md`) | Internal bug archives |
| Sub-agent review methodology | Your methodology IP |
| Old data files (`tw_persona_997.json`, prototypes) | Client only needs current version |

#### Qualified Memory Extraction from Long Conversations

When a long multi-session conversation thread (e.g., 405+ replies) contains accumulated domain knowledge, extract `qualified-memory.md` as a structured reference:

1. **Search** session history for the target thread
2. **Scroll** through anchors to capture key decisions, bugs fixed, workarounds, best practices
3. **Categorize** entries: architecture, known limits, iteration flow, Pro review tips, query best practices, commercial decisions, bug history
4. **Tag** with `#qualified` suffix so the export script picks them up
5. **Write** to `persona/qualified-memory.md` — this file auto-bundles into both Release and Appliance artifacts

Example extraction (from 2026-07-13): 24 entries from a 748-message #persona-db-dev thread, covering architecture through commercial model. See `persona/qualified-memory.md`.

### Release Artifact Structure

```
releases/release-v3.2.zip
├── VERSION                     ← v3.2
├── manifest.json               ← metadata + SHA256
├── CHANGELOG.md                ← auto-generated from #qualified entries
├── qualified-memory.md         ← merge-able memory entries
├── skills/tw-persona-db/       ← skill + scripts + references
├── data/                       ← tw_persona_1069.json + RFC + population CSV
└── tools/                      ← query_persona.py + sample_stratified.py
```

### Client Import Workflow

The client unzips and runs:

```bash
bash auto-import-qualified.sh release-v3.2.zip
```

This copies skill files to `~/.hermes/skills/`, data to `~/persona-db/`, and prompts manual review of `qualified-memory.md` before merging into `~/.hermes/memories/MEMORY.md`.

### Memory Isolation Principle

- **本尊 memory**: Contains ALL entries — iteration history, debug notes, cron results, client conversations. Some tagged `#qualified`.
- **Client memory**: Only contains `#qualified` entries from releases + their own local query history.
- **Never push**: debug logs, experimental attempts, cron/mediawatch output, other clients' conversations.

### Pricing Model (Reference)

The `#qualified` memory export enables a **monthly subscription** (vs hourly billing):

| Model | Rate | What client gets |
|:------|:----:|:-----------------|
| Hourly (舊) | NT$3,000/hr | Access to 本尊's time |
| Monthly (新) | NT$15K-25K/mo | Self-updating release artifact + `auto-import-qualified.sh` |
| Per-release | NT$8K-15K | One-time zip download |

The value proposition: clients buy **domain intelligence as a product**, not engineering hours. Each release bundles updated data, tools, skill improvements, and curated knowledge. The 本尊 maintains one core and distributes to N clients from the same release artifact.

### Adding #qualified Entries

When iterating the persona DB, tag any finding that would benefit a client:

| What to tag | Example | When |
|:------------|:--------|:-----|
| Known limitations | 「查特定城市+組合可能回0」 | On discovery |
| Best practice queries | 「選區分布用 --politics 泛綠」 | When pattern emerges |
| Version milestones | 「v3.3: 20條QA全pass」 | After QA passes |
| Dimension definitions | 「price_tier 分級依據DGBAS」 | On data change |
| Chinese tone rules | 「含飴弄孫不配低收」 | On bug fix |

Do NOT tag: debug details, experimental attempts, cron/mediawatch data, other client conversations.


- **Parent session model**: deepseek-v4-flash
- **Delegation model**: deepseek-v4-pro (set via `delegation.provider: custom:deepseek-pro` and `delegation.model: deepseek-v4-pro` in config.yaml)
- Sub-agents automatically use Pro. Parent session keeps Flash.

## QA Rules (20 Total)

| Rule | Check | Source | Added |
|:----|:------|:-------|:-----:|
| R1-R9 | Basic coherence (minors, marriage, education, distribution) | qa_validate.py | v1.0 |
| R10-R15 | Template residue (65+, 做退休, 【】, location, 獨生子, 新婚) | qa_validate.py | v2.0 |
| R16-R18 | Age gates (55+新婚, 兒孫滿堂 age, minor 泡茶) | qa_validate.py | v2.0 |
| R19 | Family size contradiction (family>1 + 「一個人過日子」) | qa_validate.py | v3.3 |
| R20 | 45+未婚說「跟爸媽住」 (45+ unmarried living with parents) | qa_validate.py | v3.5 |


- All names are fictional (stylized, not real-person names)
- All locations are synthetic compound names, not real administrative areas
- Minors use fictional school names
- Each persona JSON includes `"type": "虛構人設"` disclaimer


### Language Naturalness (中文)
- No census-form language. No "65+歳" code residue.
- No region macro-labels in prompt_prefix where possible — "住在都會區" is unnatural. Use residence (city/county) instead.
- Household descriptions must sound like a real person speaking.
- No ambiguous sibling/grandparent references — always pick specific form.
- No 「做退休」/「做學生」 — use 已經退休了/還在讀書.
- No 【】bracket format in prompt_prefix.
- Female personas: 獨生女 (not 獨生子). Male divorce: 搬回老家 (not 搬回娘家).
- No trailing location redundancy in prompt_prefix.
- 45+: not 「新婚不久」. 25-34: not 鰥寡.
- 0-11 hobbies: no 泡茶/下棋/廣場舞.

### Presentation Preference (comparison tables)

When reporting persona quality improvements or analysis results, always use a **before/after comparison table** or side-by-side format. The user finds these far more informative than prose descriptions alone. Examples:

- 「台北市(高物價): 50% 緊縮短語 vs 南投縣(極低物價): 10% 緊縮短語」
- 「Before: 有伯是阿伯，65+歲，做退休。獨生子，爸媽的寶。手頭還算寬鬆。→ After: 有伯是阿伯，住新北市。小孩都在外地。貸款和帳單壓得喘不過氣。」

This applies to code changes, quality metrics, and economic tone comparisons.

<!-- This section is consolidated below under Chinese Semantic Tone Mismatches. -->
 
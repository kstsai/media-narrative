# City Occupation Boost (OCC_CITY_BOOST)

Added 2026-07-11. Addresses the issue that national-average OCC_PROB under-represents
city-specific industry clusters (e.g., 新竹 should have ~40% tech workers, not 10%).

## Mechanism

Post-selection adjustment in `_generate_997.py` generation loop. After the base
OCC_PROB selection, if the selected occupation doesn't match the city's dominant
industry, there's a probability of redirecting to the target occupation.

## Boost Table

| City | Target | Prob | Rationale |
|------|--------|:----:|-----------|
| 新竹縣 | 科技 | 30% | 竹科 — TSMC headquarters |
| 新竹市 | 科技 | 30% | 竹科 — science park adjacent |
| 台北市 | 金融 | 20% | Finance hub — HQ of all major banks |
| 桃園市 | 製造 | 20% | 工業區 — many factories |
| 台中市 | 製造 | 15% | 精密機械 corridor |
| 台南市 | 製造 | 15% | 南部科學園區, 工業區 |
| 高雄市 | 製造 | 15% | 臨海工業區, 楠梓加工區 |

## Implementation Detail

```python
OCC_CITY_BOOST = {
    "新竹縣": {"科技": 0.30}, "新竹市": {"科技": 0.30},
    "台北市": {"金融": 0.20},
    "桃園市": {"製造": 0.20},
    "台中市": {"製造": 0.15}, "台南市": {"製造": 0.15}, "高雄市": {"製造": 0.15},
}
```

Applied after base OCC_PROB selection, before income computation. Skipped for
0-11/12-18/65+ age groups and for 學生/退休 occupations (to avoid redirecting
a student to 科技).

## Limitations

- Does not create personas from nothing — if a city has only 19 sampling slots,
  even a 30% boost can't create specific combos (e.g., 45-54 + 科技 + 4口 family).
- Only redirects, does not re-weight the full distribution.
- A pre-selection city-specific OCC_PROB table would be more accurate but requires
  more data.

## Verification

```bash
python3 query_persona.py --occ 科技 --residence 新竹市 --top 5
```

Expected: 新竹市 should have 2-3 tech workers per 20-24 personas (vs 1 without boost).

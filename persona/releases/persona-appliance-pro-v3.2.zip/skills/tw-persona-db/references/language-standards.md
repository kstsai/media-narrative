# Language & Realism Standards for Persona Generation

User Kuo-Shou Tsai enforces strict Chinese naturalness and Taiwan realism. Every fix below was discovered through iterative QA sampling — the user reads generated output and flags what sounds wrong.

## Age Descriptors (prompt_prefix)

| Age Bucket | Bad | Good |
|------------|-----|------|
| 0-11 | `0-11歲的北北基女性` | `國小女生`, `國小男生` |
| 12-18 | `12-18歲的桃竹苗男性` | `國中男生`, `高中女生` (random 50/50) |
| 19+ | keep bucket format | keep bucket format |

Implemented via `age_desc()` helper in `_generate_997.py`. Called before template selection.

## Household Phrasing

| Family Pattern | Incorrect | Correct |
|----------------|-----------|---------|
| 2-person, child + single parent | `跟其中一位家長同住` | `輪流跟爸爸或媽媽住（爸媽離婚）` |
| 4-person, parents + child + sibling | `跟父母和一個兄弟姊妹同住` | `跟爸爸媽媽和一個弟弟住` (or 妹妹/哥哥/姊姊) |
| 4-person, parents + child + grandparent | `跟爸爸媽媽和阿公或阿嬤住` | `跟爸爸媽媽和阿公住` (or 阿嬤 — no ambiguity) |
| 5+ person student family | `是家裡的大姊/大哥，要幫忙照顧弟妹` | `是家裡的老大，要幫忙照顧弟弟妹妹` |
| 5+ person student family v2 | `家裡排行老大，底下還有弟妹` | `在家裡排行老大，底下有弟弟妹妹` |

### Chinese Grammar Rules Triggered

1. **兄弟姊妹 / 手足** — collective/plural terms. Ungrammatical as singular reference:
   - ❌ `一個兄弟姊妹住` (one siblings)
   - ✅ `跟爸爸媽媽和一個弟弟住` (or 妹妹/哥哥/姊姊 — be SPECIFIC)
   - ✅ `多位兄弟姊妹住` (multiple siblings — plural context is OK)

2. **大姊/大哥** — respectful title, not natural for a child to self-describe:
   - ❌ `是家裡的大姊/大哥`
   - ✅ `是家裡的老大`

3. **哥哥或妹妹 / 阿公或阿嬤** — "or" implies the speaker doesn't know, which is unnatural for a child living with them. Always be specific:
   - ❌ `跟爸爸媽媽和一個哥哥或妹妹住`
   - ❌ `跟爸爸媽媽和阿公或阿嬤住`
   - ✅ `跟爸爸媽媽和一個弟弟住` (choose one: 弟弟/妹妹/哥哥/姊姊)
   - ✅ `跟爸爸媽媽和阿嬤住` (choose one: 阿公/阿嬤)
   - Exception: `輪流跟爸爸或媽媽住（爸媽離婚）` is OK because shared custody genuinely alternates.

4. **Birth-order gender specificity** for 5+ student families:
   - ❌ `是家裡的老么，上面有哥哥姊姊` (ambiguous)
   - ✅ `是家裡的老么，上面有哥哥` / `上面有姊姊`

## Household Composition Coherence (Age-Aware)

| Age | Family Size = 1 | Economic Phrases | Media Diet |
|-----|----------------|------------------|------------|
| 0-11 | ❌ Removed (13%→0%) | ❌ Skipped entirely | ✅ 家長主導/兒童內容 |
| 12-18 | ❌ Removed (13%→0%) | ❌ Skipped entirely | ✅ 社群為主 OK |
| 19+ | ✅ Allowed | ✅ Allowed | ✅ Normal rules |

## Education: Taiwan Realism

Adults (35+) in professional occupations (科技, 金融, 醫療) with less than 大學 education is unrealistic in Taiwan. Coherence rule bumps 國中以下/高中 → 大學.

Education levels: 國中以下 / 高中 / 大學 / 研究所以上

## Iteration Workflow

```
1. Run _generate_997.py
2. Read 3-5 random samples manually (check prompt_prefix)
3. If any sample sounds wrong → trace root cause
   - Probability table (EDU_PROB, FAMILY_SIZE_PROB, MARRIAGE_PROB, MEDIA_PROB)
   - Phrase pool (HH_*, ECON_*, LIFE_*)
   - Coherence rule (coherence_fixes dict)
   - Template (prompt_prefix generator)
4. Fix at source → regenerate → re-sample
5. Commit when no issues found in random sample
```

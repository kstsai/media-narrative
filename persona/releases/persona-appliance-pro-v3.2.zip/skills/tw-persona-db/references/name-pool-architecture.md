# Name Pool Architecture — `_generate_997.py`

## Design

Each persona needs a name that matches its demographic archetype. Names are not
random — they are drawn from **age × sex × occupation-themed pools** that cycle
via a `deque` to distribute diversity across all personas sharing the same
combination.

## Mechanism

```python
NAME_POOLS = {}  # key = (age, sex, occ) -> deque

def get_name(age, sex, occ):
    key = (age, sex, occ)
    if key not in NAME_POOLS:
        NAME_POOLS[key] = deque(_build_name_pool(age, sex, occ))
    pool = NAME_POOLS[key]
    name = pool.popleft()   # take from front
    pool.append(name)        # recycle to back
    return name
```

This is NOT a cache (old `NAME_CACHE`). Each call pops the front name and
appends it to the back — so the pool rotates continuously. A combo with 24
personas and a pool of 16 names will have each name appear ~1-2 times instead
of all 24 having the same name.

## Pool Definitions (12 pools, ~15-16 names each)

### 1. 0-11 (any sex) — Cute reduplicated

```
["糖糖","果果","樂樂","星星","蜜蜜","嘟嘟","妮妮","寶寶",
 "可可","芽芽","米米","豆豆","萌萌","天天","亮亮","晴晴"]
```

### 2. 12-18 (any sex) — Japanese 醬系

```
["小莓","星醬","芽泉","糖球","小雲","夢醬","莓果","星月",
 "小桃","蜜糖","泡泡","小葵","雨醬","熙熙","芯芯","學妹"]
```

### 3. 19-34 male, 科技/金融 — Western tech-bro

```
["阿睿","阿凱","馬克","大衛","文森","阿誠","小光","傑森",
 "艾力克","理察","丹尼爾","班","傑","洛克","諾亞","歐文"]
```

### 4. 19-34 male, other occ — 阿/小系

```
["小宇","小安","阿杰","阿豪","阿翔","小陳","阿元","阿明",
 "小傑","小林","阿峰","阿緯","小白","阿宏","大雄","小胖"]
```

### 5. 19-34 female — Anglophone trendy

```
["小艾","艾倫","莉亞","若希","安妮","凱琳","可恩","小曦",
 "愛莎","小莉","小薇","小彤","小奈","米亞","菲菲","柔伊"]
```

### 6. 35-54 male — Steady 雙字

```
["志豪","大仁","建宏","強哥","文彬","明義","世昌","志強",
 "永信","俊傑","正雄","文龍","瑞宏","協明","福來","信賢"]
```

### 7. 35-54 female — Elegant 雙字

```
["靜怡","雅雯","慧君","美珍","素芬","麗卿","淑貞","惠如",
 "美惠","麗華","惠雯","麗美","淑娟","雅芳","怡君","婉玲"]
```

### 8. 55-64 male — 本土中年 ✅ Added 2026-07-10

```
["信宏","坤成","明德","永昌","國華","耀宗","萬生","進福",
 "清輝","德勝","添財","榮發","金水","木火","朝陽"]
```

### 9. 55-64 female — 本土中年 ✅ Added 2026-07-10

```
["秀英","玉蘭","碧霞","玉琴","素雲","月鳳","金蓮","秀美",
 "含笑","美雲","彩華","阿緞","玉葉","寶珠","秀琴"]
```

### 10. 65+ male — 伯系

```
["春伯","福伯","金伯","天伯","榮伯","有伯","萬伯","土伯","坤伯",
 "松伯","柏伯","柳伯","茂伯","竹伯","梅伯"]
```

### 11. 65+ female — 嬸系

```
["春姨","麗媽","秀姨","阿好嬸","金花嬸","素蘭嬸","阿桃","阿滿","阿鳳",
 "銀嬸","玉嬸","碧嬸","月嬸","秀嬸","鳳嬸"]
```

### 12. else fallback — Mixed

```
["秀蘭","美惠","素卿","麗華","春梅","美枝","淑華","明輝",
 "俊傑","阿坤","阿利","萬福","春生","正男","水木","阿雪"]
```

## Evolution

| Version | Unique Names | Max Freq | Change |
|---------|:------------:|:--------:|--------|
| v1.0 (original) | ~80 | ~80+ | `NAME_CACHE[(age,sex,occ)]` = one name per combo |
| v1.1 (deque cycle) | 96 (9.6%) | 33 | Cache → deque cycling, but pools still 8-12 names |
| **v1.2 (this)** | **172 (17.3%)** | **13** | Expanded from 8-12 → 15-16 names. Added dedicated 55-64 pools. Expanded else fallback. |

## Verification

To check name diversity after regeneration:

```python
import json
from collections import Counter

with open("tw_persona_997.json") as f:
    data = json.load(f)

names = Counter(p["name"] for p in data)
print(f"Unique: {len(names)}/{len(data)} ({len(names)/len(data)*100:.1f}%)")
print(f"Top 5: {names.most_common(5)}")
```

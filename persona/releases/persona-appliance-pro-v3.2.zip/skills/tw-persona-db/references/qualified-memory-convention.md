# Qualified Memory Convention — Reference

## 什麼是 Qualified Memory

Qualified memory 是從本尊的 `~/.hermes/memories/MEMORY.md` 中篩選出來、適合分享給客戶的知識條目。每個條目尾端加上 `#qualified` tag 就會被 `export_qualified_memory.py` 掃描到。

## 哪些東西該加 #qualified

| 類別 | 範例 |
|:-----|:------|
| **已知限制** | 查新竹市+科技業+45-54 可能回 0，因人口權重低（新竹市~1.9%，分配後僅~20人）。建議放寬 region 或配合 city boost。 |
| **最佳作法** | 查選區分布用 `--residence 台中市 --age 30-44 --politics 泛綠`；查展店用 `--residence 高雄市 --income >8萬` |
| **版本里程碑** | 資料版本 v3.1：18 維度、20 條 QA 全 pass、年齡誤差 ≤0.3%、區域誤差 ≤0.4%、7 個官方統計源。 |
| **維度定義** | 物價分級依據 DGBAS 每人月消費支出：台北市 34,952(高)、新竹市 30,014(中高)、台東縣 18,745(極低)。 |
| **重要修正** | 65+ 應使用「子女」「兒女」而非「小孩」，避免年輕家庭語言混淆。 |
| **QA 狀態** | 目前 20 條 QA 規則全部通過，含 R1-R20。 |

## 哪些東西不該加

| 類別 | 原因 |
|:-----|:------|
| Debug 過程（「R15 regex 改第 237 行」） | 甲方不需要知道實作細節 |
| 實驗性嘗試（「試試 occupation boost 30%→50%」） | 未驗證的實驗可能誤導 |
| Cron/mediawatch 輸出 | 完全不相關 |
| 其他客戶的對話 | 隱私問題 |
| 你的個人狀態（「今天請假」） | 無關 |

## Memory 架構

```
~/.hermes/memories/
├── MEMORY.md    ← 本尊全部記憶（含 #qualified 條目）
├── USER.md      ← 使用者 profile（不 export）

客戶環境：
~/.hermes/memories/
├── MEMORY.md    ← 只有 qualified entries + 本地查詢記錄
                   （不含本尊的 debug 資訊）
```

## 發布週期建議

- **Minor release** (v3.2→v3.3)：每 1-2 週，累積 3-5 條新 #qualified 即可發布
- **Major release** (v3→v4)：資料結構變更或重大功能新增時

## 相關檔案

- `export_qualified_memory.py` — 打包 script（在 skill scripts/ 和 persona/ 下皆有）
- `templates/auto-import-qualified.sh` — 甲方端匯入腳本
- `releases/release-vX.Y.zip` — 產出的 release artifact
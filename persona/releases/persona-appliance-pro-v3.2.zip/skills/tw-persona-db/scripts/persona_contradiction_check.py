#!/usr/bin/env python3
"""
Generic persona contradiction checker.
Usage: python3 scripts/persona_contradiction_check.py <persona_file.json>

Runs 10 mechanical checks + semantic analysis on a persona JSON file.
Outputs flagged items with REAL/OK/MINOR classification.

Checks:
  1. Income level vs economic description mismatch
  2. Single-person (fs=1) mentioning children without spouse
  3. Married+fs=1 without spouse mention
  4. Minor with income (age 0-18)
  5. 65+ with young children narrative
  6. 含飴弄孫 + low income + high price tier
  7. Minor with non-student occupation
  8. Background_story internal contradictions
  9. Student + married
  10. 12-18 with university education

Adapted from chunk 4 analysis. All 10 checks work on any persona chunk.
"""

import json, sys, re

def load_personas(path):
    with open(path) as f:
        return json.load(f)

# ── Helper patterns ──
POSITIVE_PATTERNS = [
    '經濟上滿寬裕', '手頭還算寬鬆', '生活品質還不錯', '有些積蓄',
    '不用太省', '該花的會花'
]
NEGATIVE_PATTERNS = [
    '經濟壓力非常大', '月底常常手頭緊', '常常入不敷出', '能省則省',
    '不太敢亂花錢', '每一塊錢都要算清楚', '存不了什麼錢',
    '經濟上要很精打細算', '伙食費佔了開銷的大半', '房租佔掉收入快一半',
    '貸款和帳單壓得喘不過氣', '最近物價漲得很有感', '日子更緊了',
]

def pname(p):
    return f"{p['id']} {p.get('name','?')}"

def bg(p):
    return p['dimensions'].get('background_story', '')

def pp(p):
    return p.get('prompt_prefix', '')

def all_text(p):
    return bg(p) + ' ' + pp(p)

def check1(p):
    """Income level vs economic description."""
    inc = p['dimensions']['income']
    text = all_text(p)
    flags = []
    if inc == '<3萬':
        for pat in POSITIVE_PATTERNS:
            if pat in text:
                flags.append(f"低收入(<3萬)但背景有「{pat}」")
                break
    if inc == '>8萬':
        for pat in NEGATIVE_PATTERNS:
            if pat in text:
                flags.append(f"高收入(>8萬)但背景有「{pat}」")
                break
    return flags

def check2(p):
    """Single-person + children mention without spouse."""
    if p['dimensions']['family_size'] != '1':
        return []
    text = all_text(p)
    mar = p['dimensions']['marriage']
    flags = []
    child_keywords = ['小孩', '孩子', '子女', '兒女']
    has_child = any(kw in text for kw in child_keywords)
    if not has_child:
        return []
    child_core = re.search(r'(小孩|孩子|子女).*(還小|開銷|花錢)', text)
    spouse_mention = any(kw in text for kw in ['夫妻', '配偶', '老伴'])
    if child_core and not spouse_mention:
        flags.append(f"family_size=1, {mar}, 獨居但提到小孩開銷/花費: 「{child_core.group()}」")
    elif has_child and not spouse_mention:
        if not any(kw in text for kw in ['夫妻', '配偶', '老伴']):
            flags.append(f"family_size=1, {mar}, 無配偶提及但提到小孩/子女")
    return flags

def check3(p):
    """Married + fs=1 without spouse mention."""
    if p['dimensions']['marriage'] != '已婚' or p['dimensions']['family_size'] != '1':
        return []
    text = all_text(p)
    has_spouse = any(kw in text for kw in ['配偶', '夫妻'])
    if not has_spouse:
        return ["已婚+family_size=1, 背景未提及配偶"]
    return []

def check4(p):
    """Minor with income (age 0-18)."""
    age = p['dimensions']['age']
    if age not in ('0-11', '12-18'):
        return []
    inc = p['dimensions']['income']
    if inc not in ('無收入', '<3萬'):
        return [f"未成年({age})有收入: {inc}"]
    return []

def check5(p):
    """65+ with young children narrative."""
    if p['dimensions']['age'] != '65+':
        return []
    text = all_text(p)
    flags = []
    young_kid = re.finditer(r'(小孩|孩子).*?(還小|開銷|正值)', text)
    for m in young_kid:
        ctx = text[max(0,m.start()):m.start()+20]
        flags.append(f"65+但提到年輕子女: 「{ctx}」")
    return flags

def check6(p):
    """含飴弄孫 + low income + high price."""
    if '含飴弄孫' not in all_text(p):
        return []
    inc = p['dimensions']['income']
    price = p['dimensions']['price_tier']
    if inc == '<3萬' and price in ('高', '中高'):
        return [f"含飴弄孫+低收入(<3萬)+高物價({price})"]
    return []

def check7(p):
    """Minor with non-student occupation."""
    age = p['dimensions']['age']
    if age not in ('0-11', '12-18'):
        return []
    occ = p['dimensions']['occupation']
    if occ != '學生':
        return [f"未成年({age})職業不是學生: {occ}"]
    return []

def check8(p):
    """Background_story internal contradictions."""
    s = bg(p)
    flags = []
    # 沒有生小孩 + later mention of 小孩
    if '沒有生小孩' in s:
        rest = s[s.find('沒有生小孩'):]
        other_kid = rest.count('小孩') + rest.count('孩子') - 1  # -1 for the one in "沒有生小孩"
        if other_kid > 0:
            flags.append(f"說「沒有生小孩」但又提小孩/孩子: {rest}")
    # 一個人 + 兒孫滿堂/兒女成群/三代同堂
    if re.search(r'一個人', s) and re.search(r'(兒孫滿堂|兒女成群|三代同堂)', s):
        flags.append(f"「一個人」vs「兒孫滿堂/兒女成群」矛盾: {s}")
    # "現在一個人過日子" + family_size >= 4
    fs = p['dimensions']['family_size']
    if '現在一個人過日子' in s and fs in ('4', '5+'):
        flags.append(f"「現在一個人過日子」但 family_size={fs}: {s}")
    # "老伴走了" repeated
    if s.count('老伴走了') > 1:
        flags.append(f"「老伴走了」重複: {s}")
    return flags

def check9(p):
    """Student + married."""
    if p['dimensions']['occupation'] != '學生':
        return []
    mar = p['dimensions']['marriage']
    if mar != '未婚':
        return [f"學生但婚姻狀態: {mar}"]
    return []

def check10(p):
    """12-18 with university education."""
    if p['dimensions']['age'] != '12-18':
        return []
    edu = p['dimensions']['education']
    if edu == '大學':
        return ["12-18但教育程度=大學"]
    return []

ALL_CHECKS = [check1, check2, check3, check4, check5, check6, check7, check8, check9, check10]
CHECK_LABELS = [
    "Check 1: 收入 vs 描述",
    "Check 2: 獨居+小孩",
    "Check 3: 已婚+fs=1無配偶",
    "Check 4: 未成年有收入",
    "Check 5: 65+年輕子女",
    "Check 6: 含飴弄孫+低收入+高物價",
    "Check 7: 未成年非學生",
    "Check 8: BG前後句矛盾",
    "Check 9: 學生+已婚",
    "Check 10: 12-18教育=大學",
]

def semantic_judge(check_idx, p, flags):
    """
    Classify each flag as REAL, OK, or MINOR.
    Returns (judgment, explanation) per flag.
    Override this function with domain-specific logic.
    """
    # Basic heuristic: income contradictions with matching bg/pp are REAL
    results = []
    for f in flags:
        results.append(("REAL", "Mechanical match — verify manually"))
    return results

def main():
    if len(sys.argv) < 2:
        print("Usage: python3 persona_contradiction_check.py <persona_file.json>")
        sys.exit(1)
    data = load_personas(sys.argv[1])
    print(f"Loaded {len(data)} personas from {sys.argv[1]}")
    total = 0
    for i, check_fn in enumerate(ALL_CHECKS):
        flagged = []
        for p in data:
            fl = check_fn(p)
            if fl:
                flagged.append((p, fl))
        if not flagged:
            continue
        print(f"\n{'='*70}")
        print(f"  {CHECK_LABELS[i]} ({len(flagged)} flagged)")
        print(f"{'='*70}")
        for p, fl in flagged:
            d = p['dimensions']
            print(f"  ▶ {pname(p)}")
            print(f"    age={d['age']} mar={d['marriage']} fs={d['family_size']} "
                  f"occ={d['occupation']} inc={d['income']} edu={d['education']} "
                  f"price={d['price_tier']}")
            print(f"    BG: {bg(p)[:100]}")
            print(f"    PP: {pp(p)[:100]}")
            for f in fl:
                print(f"    ⚠ {f}")
        total += len(flagged)
    print(f"\n{'='*70}")
    print(f"  Total flagged: {total} across {len(data)} personas")
    print(f"{'='*70}")

if __name__ == '__main__':
    main()

#!/usr/bin/env python3
"""
TW Persona DB v3.0+ — Automated 5-Category Review Script
Usage: python3 scripts/persona_review.py [path/to/tw_persona_XXX.json]
Default: ../tw_persona_112_stratified.json

Checks 5 categories:
  A. Distribution anomalies (age vs occupation, education, family_size)
  B. Content unreasonableness (hobby vs age, background_story coherence, template residue)
  C. Language naturalness (prefix quality, economic sentences)
  D. Price tier / income tier consistency with residence
  E. Region ↔ Residence mapping correctness
"""
import json, sys, os

# Resolve default path relative to script location
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_PATH = os.path.join(SCRIPT_DIR, "..", "tw_persona_112_stratified.json")
path = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_PATH

with open(path) as f:
    data = json.load(f)

SIX_CAPITALS = {"台北市","新北市","桃園市","台中市","台南市","高雄市"}
ISLAND_COUNTIES = {"澎湖縣","金門縣","連江縣"}
HUALIEN_TAITUNG = {"花蓮縣","台東縣"}

issues = {"A": [], "B": [], "C": [], "D": [], "E": []}

for item in data:
    d = item["dimensions"]
    pid = item["id"]
    name = item["name"]
    age = d["age"]; occ = d["occupation"]; edu = d["education"]
    income = d["income"]; marriage = d["marriage"]; region = d["region"]
    residence = d["residence"]; hobbies = d["hobby"]; prefix = item.get("prompt_prefix", "")
    background = d.get("background_story", ""); price_tier = d.get("price_tier", "")
    hh_inc_tier = d.get("hh_income_tier", ""); politics = d.get("politics", "")
    fam_size = d.get("family_size", ""); fam_income = d.get("family_income", "")
    label = f"{pid}/{name}"

    # ========== A. Distribution Anomalies ==========
    if age in ("0-11","12-18") and occ not in ("學生",""):
        issues["A"].append(f"{label}: 年齡{age}但職業為{occ}，應為學生")
    if age in ("0-11","12-18") and fam_size == "1":
        issues["A"].append(f"{label}: 年齡{age}但獨居")
    if age == "0-11" and edu not in {"國中以下"}:
        issues["A"].append(f"{label}: 年齡{age}但education={edu}")
    if age == "12-18" and edu not in {"國中以下","高中"}:
        issues["A"].append(f"{label}: 年齡{age}但education={edu}，應國中以下或高中")
    if age == "0-11" and income not in ("無收入",""):
        issues["A"].append(f"{label}: 年齡{age}但income={income}")
    if age == "12-18" and occ == "學生" and income not in ("無收入","<3萬",""):
        issues["A"].append(f"{label}: 年齡{age}學生但income={income}")

    # ========== B. Content Issues ==========
    if age in ("0-11","12-18"):
        for h in hobbies:
            if h in ("泡茶","下棋","打牌","廣場舞"):
                issues["B"].append(f"{label}: 年齡{age}興趣含「{h}」不合適")
    if age == "0-11" and politics not in ("無政治傾向",""):
        issues["B"].append(f"{label}: 年齡{age}但有政治傾向")
    for phrase in ["住在都會區","住在北部","住在中部","住在南部","住在東部","住在離島"]:
        if phrase in background:
            issues["B"].append(f"{label}: background_story殘留「{phrase}」")
            break
    for phrase in ["住在都會區","住在北部","住在中部","住在南部","住在東部","住在離島"]:
        if phrase in prefix:
            issues["B"].append(f"{label}: prompt_prefix殘留「{phrase}」")
            break
    if age == "12-18" and "國小" in prefix:
        issues["B"].append(f"{label}: 年齡12-18但prefix稱「國小」")
    if age == "0-11" and ("高中" in prefix or "中學" in prefix):
        issues["B"].append(f"{label}: 年齡0-11但prefix稱「高中/中學」")

    # B: prefix school-level vs education
    if age in ("12-18", "0-11"):
        if "國中" in prefix and edu == "高中":
            issues["B"].append(f"{label}: prefix稱「國中」但education=高中")
        if "高中" in prefix and edu == "國中以下":
            issues["B"].append(f"{label}: prefix稱「高中」但education=國中以下")

    # B: background internal contradictions
    if "沒有生小孩" in background and "小孩" in background and "的開銷" in background:
        issues["B"].append(f"{label}: 說「沒有生小孩」但提「小孩開銷」")
    if "夫妻兩人世界" in background and "小孩" in background:
        issues["B"].append(f"{label}: 說「夫妻兩人世界」但提「小孩」")
    if "沒有生小孩" in background and "含飴弄孫" in background:
        issues["B"].append(f"{label}: 說「沒有生小孩」但「含飴弄孫」")
    if "沒有生小孩" in background and "小孩慢慢大了" in background:
        issues["B"].append(f"{label}: 說「沒有生小孩」但「小孩慢慢大了」")

    # ========== C. Language Naturalness ==========
    for phrase in ["【","】"]:
        if phrase in prefix:
            issues["C"].append(f"{label}: prefix含殘留符號「{phrase}」")
    if "歳" in prefix:
        issues["C"].append(f"{label}: prefix含「歳」（應為歲）")

    # C: Missing economic sentence for adults
    if age not in ("0-11", "12-18"):
        sentences = [s.strip() for s in prefix.split("。") if s.strip()]
        econ_kw = ["收入","算著花","省著點","不用太省","過得滿舒服","生活壓力","物價太高","不太夠用","剛好夠生活","還算輕鬆","算很高"]
        has_econ = any(any(k in s for k in econ_kw) for s in sentences)
        if not has_econ and occ != "學生":
            issues["C"].append(f"{label}: 年齡{age}/{occ}但prefix缺少經濟脈絡句")

    # ========== D. Price/Income Tier Consistency ==========
    if residence == "台北市":
        if price_tier != "高":
            issues["D"].append(f"{label}: 台北市但price_tier={price_tier}")
        if hh_inc_tier != "極高":
            issues["D"].append(f"{label}: 台北市但hh_income_tier={hh_inc_tier}")
    if residence == "南投縣":
        if price_tier != "極低":
            issues["D"].append(f"{label}: 南投縣但price_tier={price_tier}")
        if hh_inc_tier != "中低":
            issues["D"].append(f"{label}: 南投縣但hh_income_tier={hh_inc_tier}")
    if residence == "台東縣" and hh_inc_tier != "低":
        issues["D"].append(f"{label}: 台東縣但hh_income_tier={hh_inc_tier}")

    # D: Economic sentence vs residence/income consistency
    if age not in ("0-11","12-18") and prefix:
        sentences = [s.strip() for s in prefix.split("。") if s.strip()]
        econ_sent = None
        for s in reversed(sentences):
            if any(k in s for k in ["收入","算著花","省著點","不用太省","過得滿舒服","生活壓力","物價太高","不太夠用","還不錯","要算著花","剛好夠生活","還算輕鬆"]):
                econ_sent = s; break
        if econ_sent:
            # Taipei + high income → tight
            if residence == "台北市" and income == ">8萬":
                if "還不錯" in econ_sent or "不用太省" in econ_sent:
                    issues["D"].append(f"{label}: 台北市+>8萬但經濟句偏鬆「{econ_sent}」")
            # Taitung/Hualien + high income → comfortable
            if residence in ("台東縣","花蓮縣") and income == ">8萬":
                if "省著點" in econ_sent or "生活壓力" in econ_sent:
                    issues["D"].append(f"{label}: {residence}+>8萬但經濟句偏緊「{econ_sent}」")
            # Low income + high cost → tight
            if income == "<3萬" and price_tier in ("高","中高"):
                if "還不錯" in econ_sent or "不用太省" in econ_sent:
                    issues["D"].append(f"{label}: 收入{income}+{residence}({price_tier})但經濟句偏鬆")

    # ========== E. Region ↔ Residence Mapping ==========
    if region == "都會區(六都)" and residence not in SIX_CAPITALS:
        issues["E"].append(f"{label}: region={region}但residence={residence}")
    elif region == "離島" and residence not in ISLAND_COUNTIES:
        issues["E"].append(f"{label}: region={region}但residence={residence}")
    elif region == "花東" and residence not in HUALIEN_TAITUNG:
        issues["E"].append(f"{label}: region={region}但residence={residence}")
    elif region == "北部":
        valid_north = {"宜蘭縣","新竹縣","新竹市","苗栗縣","基隆市"}
        if residence not in valid_north:
            issues["E"].append(f"{label}: region={region}但residence={residence}")
    elif region == "中部":
        valid_central = {"台中市","彰化縣","南投縣","雲林縣"}
        if residence not in valid_central:
            issues["E"].append(f"{label}: region={region}但residence={residence}")
    elif region == "南部":
        valid_south = {"嘉義縣","嘉義市","屏東縣","台南市","高雄市"}
        if residence not in valid_south:
            issues["E"].append(f"{label}: region={region}但residence={residence}")

# Output
cat_names = {"A":"🟡 分布異常","B":"🔴 內容不合理","C":"🔴 語言自然度","D":"🔴 物價/所得維度","E":"🔴 Region/Residence一致性"}
total = 0
for k in ["A","B","C","D","E"]:
    print(f"\n### {cat_names[k]}（{len(issues[k])}筆）")
    if not issues[k]:
        print("  ✓ 無異常")
    else:
        for iss in issues[k]:
            print(f"  {iss}")
            total += 1
print(f"\n📊 總計：{total} 筆")

#!/usr/bin/env python3
"""Verify economic tone alignment in persona chunks.

Two-pass verification:
  Pass 1 — Mechanical: scan background_story for comfort/tight keywords vs
             prompt_prefix end-of-sentence economic context.
  Pass 2 — Semantic: flag only where the same dimension (personal income,
             family income, family size) drives genuinely contradictory signals.

Usage:
  python3 scripts/verify_economic_tone.py <chunk_file.json>
  # Default: /home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_6.json

Returns exit code = number of contradictions found.
"""

import json, sys, os

RELAXED_WORDS = [
    '寬裕', '不用太省', '還不錯', '有些積蓄',
    '該花的會花', '生活品質還不錯', '手頭還算寬鬆'
]
TIGHT_WORDS = [
    '手頭緊', '入不敷出', '省着點', '很省', '要省',
    '精打細算', '經濟壓力', '存不了什麼', '很緊', '佔了開銷'
]

def load(path):
    with open(path) as f:
        return json.load(f)

def check_persona(p):
    d = p['dimensions']
    bg = d['background_story']
    pre = p['prompt_prefix']
    inc = d['income']
    name = p['name']
    pid = p['id']

    bg_relaxed = any(w in bg for w in RELAXED_WORDS)
    bg_tight = any(w in bg for w in TIGHT_WORDS)
    pre_relaxed = any(w in pre for w in RELAXED_WORDS)
    pre_tight = any(w in pre for w in TIGHT_WORDS)

    issues = []

    # Pattern 1: bg comfortable → pre tight
    if bg_relaxed and pre_tight:
        issues.append({
            'pattern': 'bg_comfortable_to_pre_tight',
            'detail': f'BG says comfortable ({[w for w in RELAXED_WORDS if w in bg]}) → PRE says tight ({[w for w in TIGHT_WORDS if w in pre]})',
            'bg_snippet': bg[:100],
            'pre_snippet': pre[:100]
        })

    # Pattern 2: bg tight → pre comfortable
    if bg_tight and pre_relaxed:
        issues.append({
            'pattern': 'bg_tight_to_pre_comfortable',
            'detail': f'BG says tight ({[w for w in TIGHT_WORDS if w in bg]}) → PRE says comfortable ({[w for w in RELAXED_WORDS if w in pre]})',
            'bg_snippet': bg[:100],
            'pre_snippet': pre[:100]
        })

    # Pattern 3: family_size=1 but bg implies cohabitation
    if d.get('family_size') == '1' and d.get('marriage') == '已婚':
        if '夫妻兩人' in bg or '一起住' in bg:
            issues.append({
                'pattern': 'fam1_couple_cohabiting',
                'detail': f'married={d["marriage"]} fam={d["family_size"]} but bg says couple lives together',
                'bg_snippet': bg[:120]
            })

    # Pattern 4: single-person household where personal_income ≠ family_income
    if d.get('marriage') in ('離婚', '鰥寡', '未婚') and d.get('family_size') == '1':
        inc_val = d.get('income', '')
        fam_inc_val = d.get('family_income', '')
        inc_order = {'無收入': 0, '<3萬': 1, '1-3萬': 2, '3-7萬': 3, '3-8萬': 3, '7萬': 4, '>8萬': 5, '百萬': 6}
        if inc_val in inc_order and fam_inc_val in inc_order:
            diff = abs(inc_order[inc_val] - inc_order[fam_inc_val])
            if diff >= 2:
                issues.append({
                    'pattern': 'single_income_mismatch',
                    'detail': f'personal_income={inc_val} ≠ family_income={fam_inc_val} (diff={diff} tiers) for single-person household',
                    'bg_snippet': bg[:100]
                })

    return issues

def main():
    path = sys.argv[1] if len(sys.argv) > 1 else \
        '/home/ubuntu/lab-riscv/hermesa3/persona/tw_persona_chunk_6.json'

    data = load(path)
    all_issues = []
    for p in data:
        pid = p['id']
        name = p['name']
        issues = check_persona(p)
        for iss in issues:
            all_issues.append((pid, name, iss))

    print(f"Verified {len(data)} personas from {os.path.basename(path)}")
    print(f"Found {len(all_issues)} economic tone issues\n")

    by_pattern = {}
    for pid, name, iss in all_issues:
        pat = iss['pattern']
        by_pattern.setdefault(pat, []).append((pid, name, iss))

    for pat, items in sorted(by_pattern.items()):
        print(f"  [{pat}] {len(items)} instances")
        for pid, name, iss in items:
            print(f"    {pid} {name}")
            print(f"      detail: {iss['detail']}")
            print(f"      BG: {iss['bg_snippet']}")
            if 'pre_snippet' in iss:
                print(f"      PRE: {iss['pre_snippet']}")
            print()

    return len(all_issues)

if __name__ == '__main__':
    sys.exit(main())
